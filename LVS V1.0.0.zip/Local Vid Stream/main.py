from fastapi import FastAPI, Request
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.staticfiles import StaticFiles
import os

app = FastAPI()

MOVIE_FOLDER = "./Movies"
SUPPORTED_FORMATS = ['.mp4']

# Mount the static directory to serve icons and favicon
app.mount("/static", StaticFiles(directory="static"), name="static")

@app.get("/", response_class=HTMLResponse)
async def get_homepage(request: Request):
    items = os.listdir(MOVIE_FOLDER)
    folders = [item for item in items if os.path.isdir(os.path.join(MOVIE_FOLDER, item))]
    movies = [item for item in items if item.endswith(tuple(SUPPORTED_FORMATS)) and not item.startswith('.')]
    
    folder_items = "".join([f"<li><img src='/static/folder_icon.png' alt='Folder Icon' width='20' height='20'> <a href='/folder/{folder}'>{folder}</a></li>" for folder in folders])
    movie_items = "".join([f"<li><img src='/static/movie_icon.png' alt='Movie Icon' width='20' height='20'> <a href='/watch/{movie}'>{movie}</a></li>" for movie in movies])
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Efflux by Shaad</title>
        <link rel="icon" type="image/x-icon" href="/static/logo.ico">
        <style>
            body {{
                font-family: Arial, sans-serif;
                background-color: #1A3534;
                color: #EDEDED;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                text-align: left;
            }}
            .container {{
                background-color: #10201F;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                border-radius: 8px;
                padding: 20px;
                max-width: 600px;
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                position: relative;
            }}
            h1 {{
                margin-bottom: 20px;
                background-color: #010102;
                border-radius;
                padding: 40px;
                border-radius: 8px;
                text-align: center;
                width: 100%;
            }}
            ul {{
                list-style: none;
                padding: 0;
                width: 100%;
            }}
            li {{
                margin: 10px 0;
                display: flex;
                align-items: center;
            }}
            img {{
                margin-right: 10px;
            }}
            a {{
                text-decoration: none;
                color: #F8F4D8;
            }}
            a:hover {{
                text-decoration: underline;
            }}
            .whatsapp {{
                position: absolute;
                top: 10px;
                right: 10px;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1><< Efflux ></h1>
            <a href="https://wa.me/+919717972620?text=Hello%2C%20Found%20Your%20Number%20On%20Efflux" class="whatsapp"><img src="/static/whatsapp.png" alt="WhatsApp Logo" width="60" height="60"></a>
            <ul>
                {folder_items}
                {movie_items}
            </ul>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@app.get("/folder/{folder_name}", response_class=HTMLResponse)
async def get_folder_contents(request: Request, folder_name: str):
    folder_path = os.path.join(MOVIE_FOLDER, folder_name)
    if not os.path.exists(folder_path):
        return HTMLResponse(content="<h1>Folder not found</h1>", status_code=404)
    
    items = os.listdir(folder_path)
    folders = [item for item in items if os.path.isdir(os.path.join(folder_path, item))]
    movies = [item for item in items if item.endswith(tuple(SUPPORTED_FORMATS)) and not item.startswith('.')]
    
    folder_items = "".join([f"<li><img src='/static/folder_icon.png' alt='Folder Icon' width='20' height='20'> <a href='/folder/{folder_name}/{folder}'>{folder}</a></li>" for folder in folders])
    movie_items = "".join([f"<li><img src='/static/movie_icon.png' alt='Movie Icon' width='20' height='20'> <a href='/watch/{folder_name}/{movie}'>{movie}</a></li>" for movie in movies])
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>{folder_name}</title>
        <link rel="icon" type="image/x-icon" href="/static/logo.ico">
        <style>
            body {{
                font-family: Arial, sans-serif;
                background-color: #1A3534;
                color: #EDEDED;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
                text-align: left;
            }}
            .container {{
                background-color: #10201F;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                border-radius: 8px;
                padding: 20px;
                max-width: 600px;
                width: 100%;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
            }}
            h1 {{
                margin-bottom: 20px;
                background-color: #004d40;
                padding: 10px;
                border-radius: 8px;
                text-align: center;
                width: 100%;
            }}
            ul {{
                list-style: none;
                padding: 0;
                width: 100%;
            }}
            li {{
                margin: 10px 0;
                display: flex;
                align-items: center;
            }}
            img {{
                margin-right: 10px;
            }}
            a {{
                text-decoration: none;
                color: #F8F4D8;
            }}
            a:hover {{
                text-decoration: underline;
            }}
        </style>
    </head>
    <body>
        <div class="container">
            <h1>Contents of {folder_name}<br></h1>
            <ul>
                {folder_items}
                {movie_items}
            </ul>
        </div>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@app.get("/watch/{folder_name}/{movie_name}", response_class=HTMLResponse)
async def watch_movie_in_folder(request: Request, folder_name: str, movie_name: str):
    movie_path = os.path.join(MOVIE_FOLDER, folder_name, movie_name)
    if not os.path.exists(movie_path):
        return HTMLResponse(content="<h1>Movie not found</h1>", status_code=404)
    
    html_content = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Watching {movie_name}</title>
        <style>
            body {{
                font-family: Arial, sans-serif;
                background-color: #000;
                color: #fff;
                display: flex;
                justify-content: center;
                align-items: center;
                height: 100vh;
                margin: 0;
            }}
            video {{
                width: 80%;
                height: auto;
                border-radius: 8px;
                box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
            }}
            a {{
                position: absolute;
                top: 20px;
                left: 20px;
                text-decoration: none;
                color: #007bff;
            }}
        </style>
    </head>
    <body>
        <a href="/">Back to Home</a>
        <video controls autoplay>
            <source src="/movies/{folder_name}/{movie_name}" type="video/mp4">
            Your browser does not support the video tag.
        </video>
    </body>
    </html>
    """
    return HTMLResponse(content=html_content)

@app.get("/movies/{folder_name}/{movie_name}")
async def get_movie_in_folder(folder_name: str, movie_name: str):
    movie_path = os.path.join(MOVIE_FOLDER, folder_name, movie_name)
    if os.path.exists(movie_path):
        return FileResponse(path=movie_path, media_type='video/mp4')
    return HTMLResponse(content="<h1>Movie not found</h1>", status_code=404)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
