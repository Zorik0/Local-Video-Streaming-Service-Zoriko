Step0 : run reqirement.bat to install the libs required
Step1 : Check what local ip you've been assigned by using "ipconfig" in cmd
Step2 : Open Main.py and at the last line change host = "0.0.0.0" to your local ip
Step3 : Open "Movies" Folder and put whatever you wish to stream on your Local Network 
